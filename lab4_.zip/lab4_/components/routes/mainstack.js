import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator} from "@react-navigation/drawer"; 


import homestack from './homestack';
import aboutstack from './aboutstack';

const Drawer = createDrawerNavigator();

const MainNavigator = () => {
return(
  <NavigationContainer>
  <Drawer.Navigator>
  
  <Drawer.Screen  name="Home" component ={ homestack } />
    <Drawer.Screen  name="About" component ={ aboutstack } />

 
  </Drawer.Navigator>
  </NavigationContainer>
);
}

export default MainNavigator;






