import React, { useState,useEffect } from 'react';
import { Text, View, Image, ActivityIndicator,Button,StyleSheet,TouchableOpacity} from 'react-native';
import Profile from '../screens/Profile';


 const Home = ({ navigation }) => {
   const [data, setData] = useState([]);
  const [name, setName] = useState('');
  const [imageLink, setimageLink] = useState('');  
  const [isLoading, setLoading] = useState(true);
  


    function fetchRandomData(){
        setLoading(true);
        fetch('https://randomuser.me/api')
        .then((response) => response.json())
        .then((json) => {
            setData(json.results[0]);
            console.log(json.results[0]);
        })
        .catch((error) => console.log(error))
        .finally(() => setLoading(false));
    }

    useEffect(() => {
        fetchRandomData();
    }, []);

    return (
      
        <View style={styles.container}>
              <View style={styles.text}>
               { isLoading ? <ActivityIndicator size="medium" color ="black" /> : (
              <TouchableOpacity onPress={() => navigation.navigate('Profile', data)}>
               <Image style={styles.image} source={{uri: data.picture.medium}}></Image>
          </TouchableOpacity>
            )}
      </View>


      <View style={styles.text}>
          { isLoading ? true : (
          <Text style={styles.text1}>{data.name.first} {data.name.last}</Text>
            )}
       </View>

      <View style={styles.text}>
      
           <View style={styles.button}>
                    { isLoading ? true : (
                    <Button title="Random User" onPress={() => {fetchRandomData();}} />
                    )} 
                    </View>
      </View>

      </View>
 );
}

export default Home;

const styles = StyleSheet.create (
  
    {
       image:
        {
            width: 150,
            height: 150,
            resizeMode: "cover",
            marginTop: 200
        },

        container:
        {
            flex: 1,
            justifyContent: 'center'
        },

        button:
        {
            marginBottom: 200
        },

        text:
        {
            flex:1,
            alignItems: 'center',
            justifyContent: 'center'
        },
        
        text1: 
        { 
            fontWeight: "bold",
            fontSize: 20,
            textAlign: "center",
        }
        
    }
)