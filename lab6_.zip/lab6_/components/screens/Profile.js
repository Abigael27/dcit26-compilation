import React from "react";
import { Button,Image,ImageBackground,ScrollView,StyleSheet,Text,View} from "react-native";
import { Icon } from 'react-native-elements'



const Profile = ( {route} ) => {

    const data = route.params;

    return (
     <View style={styles.container}>

            <View style={styles.text}>
            <Image style={styles.image} source={{uri: data.picture.medium}}></Image>
            </View>
            <Text style={styles.text1}> {data.name.title} {data.name.first} {data.name.last}</Text>
            
            <Text>
             <Icon name="people" color="#a9a9a9" size={20}/> 
<Text style = {styles.text2}>About</Text>
</Text>

            <Text> Age: {data.dob.age} </Text>
            <Text> Birthday: {data.dob.date} </Text>
            <Text> Gender: {data.gender} </Text>
            <Text style={styles.text3}> Address: {data.location.street.number} {data.location.street.name}, {data.location.city}, {data.location.state}, {data.location.country}</Text>
            


      
            <Text>
             <Icon name="email" color="#a9a9a9" size={20}/> 
<Text style = {styles.text2}>Contact</Text>
</Text>
            <Text> Email: {data.email} </Text>
            <Text style={styles.text3}> Phone: {data.phone} </Text>
          

            <Text style={styles.text2}>... Other</Text>
            <Text style={styles.text3}> Date Registered: {data.registered.date} </Text>
</View>
            
    );
}

export default Profile;

const styles = StyleSheet.create (
    {

        container:
        {
            flex: 1,
            justifyContent: 'center'
        },

        image:
        {
            alignItems: 'center',
            resizeMode: "cover",
            height: 275,
            width: 275
        },
        
        text:
        {
            flex:1,
            alignItems: 'center',
            justifyContent: 'center'
        },
        
        text1: 
        { 
            fontWeight: "bold",
            fontSize: 25,
            textAlign: "center",
            marginBottom: 50,
            justifyContent: "center"
        },

        text2:
        {
            
            color: "#a9a9a9",
            fontSize: 17,
        },

        text3:
        {
            marginBottom: 50
        },
 
    }
)
