import React, { useState } from "react";
import { View, StyleSheet, FlatList, Text, TouchableOpacity} from "react-native";

const Home = ({ navigation }) => {

const [ products, setProducts ] = useState ([

{ title: 'Xbox', description: 'loren ipsum', rating: "5/5", key: '1'},
{ title: 'PS5', description: 'loren ipsum', rating: "3/3", key: '2'},
{ title: 'Nintendo Switch', description: 'loren ipsum', rating: "4/4", key: '3'}
]);

return (
  <View style ={ styles.container }>
  <FlatList
  data={products}
  renderItem={({item}) =>(
    <TouchableOpacity
    style={styles.productBtn}
    onPress={() => navigation.navigate('Product', item)}>
    <Text style={styles.productText}>{ item.title }</Text>
    
    </TouchableOpacity>
  )}
/>
  </View>
);
};

export default Home;

const styles = StyleSheet.create ({
 container: {
    flex: 1,
    padding: 20
  },
  productBtn: {
    borderWidth: 1,
    borderColor: "#333",
    padding: 10,
    marginBotton: 10
  },
  productText:{
    fontSize: 16

  }
});

