import React from "react"; 
import { View, StyleSheet, Text } from "react-native";



const Product = ({ route, navigation }) => {
return(
<View style={styles.container}>
<Text>{ route.params.title } </Text>
<Text>{ route.params.rating } </Text>
<Text>{ route.params.description } </Text>
</View>
);
};
export default Product;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
});


