import React from "react";
import { createStackNavigator } from "@react-navigation/stack";

import Home from '../screens/Home';
import Product from '../screens/Product';
const Stack = createStackNavigator();

const HomeStack = () => {
return(
  <Stack.Navigator>
  <Stack.Screen name = "Home" component={Home} />
  <Stack.Screen name = "Product" component={Product} />
  </Stack.Navigator>
);
};

export default HomeStack;






