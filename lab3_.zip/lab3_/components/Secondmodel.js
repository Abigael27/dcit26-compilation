import React from 'react';
import {
  Button,
  Modal,
  ScrollView,
  View,
  Text,
  Image,
  StyleSheet,
} from 'react-native';

const Secondmodel = (props) => {
  return (
    <Modal visible={props.visible}>
    
      <ScrollView>
    
        <View style={styles.container}>
         <View>
          <Image
            style={{width: 100,
    height: 100,
   }}
            
            
            source= {{
              uri:
                'https://reactjs.org/logo-og.png'
           }}/>
           
        </View>
        
        
         <Text style ={styles.text}>
            The overall trajectory of Glory hews closely to the historical
            record the script relies heavily on Shaw’s letters home during his
            time in the army (a title card opening the movie refers to the
            correspondence.) Over the course of just over two hours, viewers
            move from Battle of Antietam to the regiment’s military training to
            the deep South of Georgia and South Carolina. The movie's climax,
            involving the 54th’s failed attack at Battery Wagner on July 18,
            1863, depicts a final victory over adversity and a collective
            sacrifice around the flag. Shaw is killed attempting to lead his men
            in a final assault as is Trip, who falls having finally embraced the
            regimental colors. {'\n\n'}
            When Glory was first released in 1989, it challenged a deeply
            entrenched popular memory of the war that centered the conflict
            around brave white soldiers and left little room to grapple with the
            tough questions of slavery and emancipation. The film’s most
            important contribution is its success in challenging this narrow
            interpretation by reminding white Americans of the service of
            roughly 200,000 Black Americans in Union ranks and their role in
            helping to win the war and end slavery. By 1863, the outcome of the
            war was far from certain. Following the signing of the Emancipation
            Proclamation on January 1 of that year, President Abraham Lincoln
            authorized the raising of Black troops to help defeat the
            Confederacy. There was no more enthusiastic supporter of this policy
            than Massachusetts Governor John Andrew, who immediately commenced
            with the raising of the 54th Massachusetts, along with two other
            all-black units. {'\n\n'}
            Shaw was a young 25-year-old at the time, and Broderick ably emotes
            the challenges the colonel faced overcoming his own racial
            prejudices while in command of the regiment, despite his family’s
            abolitionist credentials. Yet the movie falls short in capturing the
            extent of Shaw’s ambivalence toward being offered the command of the
            all-black regiment. In the movie, it’s played as a question that
            demanded but a few moments of reflection, when in reality Shaw
            initially rejected the governor’s commission citing concerns about
            whether commanding black soldiers would advance his own career and
            reputation in the army. His letters home throughout the first half
            of the war reveal more ambiguity about emancipation than the film
            acknowledges. {'\n\n'}
            In a letter written to his mother following the battle of Antietam,
            Shaw questioned Lincoln’s issuance of the Preliminary Emancipation
            Proclamation. “For my part,” Shaw wrote, “I can’t see what practical
            good it can do now. Wherever our army has been, there remain no
            slaves, and the Proclamation will not free them where we don’t go.”{' '}
            {'\n\n'}
            One of the most accurate scenes in the movie is the burning of
            Darien, Georgia, on June 11, 1863. Shaw and his men accompanied
            Colonel James Montgomery’s force and did, as depicted, help to set
            fire to the town. Shaw was, in fact, concerned that the incident
            would reflect negatively on his men and prevent them from ever
            having the opportunity to fight in battle. The movie Shaw’s threat
            to expose General David Hunter’s illegal activity has no basis in
            truth, but more importantly, his relationship with Montgomery was
            much more complex than that written. Shaw respected Montgomery’s
            commitment to his abolitionist principles and belief that Southern
            society needed to be completely remade, despite his racist outlook
            on the men under his command. In a letter to his wife, Shaw
            described Montgomery as a “very conscientious man” and later to his
            mother admitted that “he is very attractive to me, and indeed I have
            taken a fancy to him.” {'\n\n'}
            Notably, the movie also ignores the fact that Shaw spent significant
            time away from his men during the war, particularly during the time
            when they would have been training, as he was engaged to and later
            married Anna Kneeland Haggerty on May 2, 1863, just weeks before the
            regiment was scheduled to ship out to Beaufort, South Carolina.{' '}
            {'\n\n'}
            Among its other dramatic licenses is the depiction of the regiment
            as made up primarily of the formerly enslaved, a creative choice
            that highlights a transition from slavery to freedom. While the
            story of emancipated men becoming soldiers and fighting for their
            freedom provides a powerful narrative that was indeed true of most
            black regiments, the 54th Massachusetts was made up primarily of
            free black men born in states like Ohio, Pennsylvania and New York.
            In contrast to scenes that show Shaw struggling to procure weapons,
            food, uniforms or other supplies, the soldiers lacked very little
            owing to Governor Andrew’s commitment to black enlistment. {'\n\n'}
            In one of the most powerful scenes in the movie, Washington’s Trip
            is whipped by an Irish drill sergeant for leaving camp without
            permission in front of the entire regiment. The sight of a
            bare-backed former slave with old whipping marks still visible
            certainly works to stir the emotions of viewers, but had little
            basis in fact as the army had already banned the practice of
            flogging. {'\n\n'}
            What these deviations from the historical record do accomplish,
            however, is reinforcing the truth that black soldiers experienced
            dangers on the battlefield and racial discrimination that white
            enlisted men never faced. Delivering this message is another of
            Glory’s key additions to the public’s understanding of the United
            States Colored Troops. These men were subject to racial taunts and
            abuse by white soldiers and were forced to engage in manual labor by
            officers who didn’t believe they had the skill or bravery to engage
            in combat. {'\n\n'}
            This discrimination extended to the government’s decision to pay
            black men $10 per month (as compared to white soldiers’ $13). This
            policy is briefly addressed by the movie when Colonel Shaw joins his
            men in tearing up their pay vouchers. The scene offers another
            opportunity for Shaw to work through his own prejudices and bond
            with his men, but leaves viewers with the question of whether the
            policy was ever discontinued. It was not. {'\n\n'}
            The 54th Massachusetts and other Black regiments continued to
            protest their unequal pay following Shaw’s death in July 1863 and
            through much of 1864. Even Governor Andrew’s offer to pay the $3
            difference out of state funds was met with a stern refusal by the
            regiment. Discipline deteriorated in the 54th Massachusetts and
            other regiments as men engaged in insubordinate behavior in response
            to their unequal pay. In April 1864, 75 men in the 55th
            Massachusetts flirted with open mutiny by appealing to President
            Lincoln for immediate assistance. Congress finally discontinued the
            policy in the summer of 1864, but not before a soldier in the 55th
            Massachusetts was executed for striking his commander twice in the
            face after refusing to follow an order. {'\n\n'}
            While Glory presents the regiment’s failed assault on Battery Wagner
            as its greatest achievement, their extended protest against unequal
            pay helps to align the service of Black soldiers within the broader
            history of civil rights, and perhaps is an even stronger connection
            to modern-day protests against racial injustice. {'\n\n'}
            The movie also leaves little to the imagination in exposing the
            horrors of Civil War combat, but only alludes to the full range of
            dangers experienced by black soldiers on the battlefield. Black
            soldiers that met the enemy on Civil War battlefields were massacred
            on more than one occasion (most notably at Fort Pillow and the
            Crater in 1864) after being captured by Confederates, who viewed
            them as slaves in rebellion rather than soldiers that were protected
            by the rules of war. Some were even sold into slavery rather than
            sent to prison camps. White officers like Shaw also risked being
            executed for inciting slave rebellion. {'\n\n'}
            The final scene in which Confederates bury Shaw along with the rest
            of his now shoeless men in a mass grave brings the story to a
            fitting close by suggesting that he and his men managed to triumph
            over racism within the ranks in a war that ultimately led to
            Confederate defeat, the preservation of the Union and a "new birth
            of freedom." (The regiment’s story continues off screen, as it saw
            military action through the end of the war and remained stationed in
            South Carolina until December 1865, when it returned home to be
            decommissioned.) {'\n\n'}{' '}
          </Text>
          <Button title = 'Close' color = 'green' onPress={props.onClose}/>
        </View>
      </ScrollView>
    </Modal>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    textAlign: "center"

  },
    
  text:{
    textAlign: 'justify'},
   


 
    

});
export default Secondmodel;
