//Casas, Abigael
//Cariaso, Decee Miles
//Villazon, Luz Francis Anne
//Balmaceda, Christian
import React, {useState} from 'react';
import { View, Button, StyleSheet, ScrollView, Image, Text} from 'react-native';

import Secondmodel from './components/Secondmodel';

export default function App() {
   const [isModalOpen, setIsModalOpen] = useState(false);

  return (

    <View style={styles.container}>
    <Button title="CLICK ME" onPress={() => setIsModalOpen(true)} />
    <Secondmodel visible ={isModalOpen} onClose= {() => setIsModalOpen(false)} />
</View>
  );
}
  

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundcolor: 'pink'
    
},
});
