// BSCS 3-1
//Casas,Abigael
//Villazon,Luz Francis Anne
//Balmaceda,Christian
//Cariaso,Decee Miles


import React from 'react';
import { View, Text } from 'react-native';

export default function App() {
  return (
    <View style={{
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'skyblue',
    justifyContent: 'center'
    }}>
    <Text>Hello World</Text>
    </View>
  );
}
