//Casas, Abigael
//Cariaso, Decee Miles
//Villazon, Luz Francis Anne
//Balmaceda, Christian

import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Button} from 'react-native';

export default function App(){
  const [yourenterItem, setyourenterItem] = useState('');
  const [yourcourseItem, setyourcourseItem] = useState([]);

  const addinput = () => {
    setyourcourseItem(yourcurrentItem => [...yourcurrentItem, yourenterItem]);
    this.addyourenterItem.clear();

  }

  return (
    <View styles = {styles.screen}>
    <View style = {styles.inputone}>
    <TextInput placeholder = "Enter Item"
style = {styles.input}
onChangeText = {(newItem) => setyourenterItem (newItem)
}
ref = {input => {this.addyourenterItem = input 
}}
/>
<Button title = "ADD" onPress={addinput} />
</View>
<View>
{yourcourseItem.map((item) => <View style={styles.backg}><Text>{item}</Text>}
</View>)}
</View>
</View>
  );
  }
const styles = StyleSheet.create({
  screen: 
{
    padding: 30
},
inputone: {
  flexDirection: 'row',
  justifyContent:'space-between',
  alignITems: 'center'
},
input: {
  width: '85%',
  bordercolor: 'black',
  borderwidth: 3,
  padding: 3
},
backg: {
  backgroundColor: 'red',
  padding: 5,
  marginVertical:2,
  borderColor: 'black',
  borderWidth: 3
},
});

